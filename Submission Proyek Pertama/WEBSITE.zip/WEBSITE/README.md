Api Dicoding = 'https://story-api.dicoding.dev/v1';
Key MapTiler= 'pGG8hVIJSfVPuzEtT1Eu';